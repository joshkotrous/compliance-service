import {applyComplianceRules} from "compliance-service";

export const handler = async (event, context) => {
    try {
        // Parse the event body if it's a string
        let parsedEvent;
        if (typeof event.body === 'string') {
            parsedEvent = JSON.parse(event.body);
        } else {
            parsedEvent = event;
        }

        console.log('Received event:', JSON.stringify(parsedEvent, null, 2));

        const productInfo = parsedEvent.product;

        const states = parsedEvent.states;

        // Log the product info that will be mapped
        console.log("Applying compliance rules to: \n", productInfo, "\n");

        // Invoke module to map the data
        const mappedData = applyComplianceRules(states, productInfo);

        console.log(JSON.stringify(mappedData, null, 2));
        
        // Return the mapped data
        return mappedData;
    } catch (error) {
        return `{\"error\": \"${error.message}\"}`;
    }
};
